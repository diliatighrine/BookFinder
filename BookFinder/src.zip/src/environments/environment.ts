export const environment = {
  production: false,  // Ensure this field exists
  firebaseConfig: {
    apiKey: "AIzaSyDUuv5qwR_8w-kQenygQd8BxOzDchZFUX0",
    authDomain: "bookfinder-fa129.firebaseapp.com",
    projectId: "bookfinder-fa129",
    storageBucket: "bookfinder-fa129.firebasestorage.app",
    messagingSenderId: "961922236889",
    appId: "1:961922236889:web:805fa80ec8c33e723999c8",
    measurementId: "G-4VRYK39TX1"
  }
  };
