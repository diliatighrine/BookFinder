import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { provideFirebaseApp, initializeApp } from '@angular/fire/app';
import { provideAuth, getAuth } from '@angular/fire/auth';
import { provideFirestore, getFirestore } from '@angular/fire/firestore';
import { provideStorage, getStorage } from '@angular/fire/storage'; // ✅ Add Firebase Storage
import { provideAnalytics, getAnalytics } from '@angular/fire/analytics'; // ✅ Add Firebase Analytics
import { environment } from './environments/environment';

bootstrapApplication(AppComponent, {
  providers: [
    provideFirebaseApp(() => initializeApp(environment.firebaseConfig)),  // ✅ Initializes Firebase
    provideAuth(() => getAuth()),  // ✅ Fixes AngularFireAuth Issue
    provideFirestore(() => getFirestore()), // ✅ Fixes Firestore Issue
    provideStorage(() => getStorage()), // ✅ Adds Firebase Storage
    provideAnalytics(() => getAnalytics()) // ✅ Adds Firebase Analytics
  ]
}).catch(err => console.error(err));
