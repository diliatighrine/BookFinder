import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {BookDetailComponent} from './features/books/components/book-detail/book-detail.component';
import {LoginComponent} from './features/authentification/components/login/login.component';

export const routes: Routes = [
    {
        path: '',
        loadChildren: () => import('./features/books/books.module').then(m => m.BooksModule)
    },
    {
        path: '**',
        redirectTo: ''
    },
    {
        path: 'book/:id',
        component: BookDetailComponent
    },
    {   path: 'login',
        component: LoginComponent
    },



];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
