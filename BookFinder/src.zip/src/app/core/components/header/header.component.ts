import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import {map} from 'rxjs/operators';
import {AuthService} from '../../services/auth.service';
import {BookService} from '../../services/book.service';
import {AsyncPipe, NgIf} from '@angular/common';
import {RouterLink, RouterLinkActive} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  standalone: true,
  imports: [
    NgIf,
    AsyncPipe,
    RouterLink,
    RouterLinkActive
  ],
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  currentUser$: Observable<any> | undefined;
  favoritesCount$: Observable<number> | undefined;

  constructor(private authService: AuthService, private bookService: BookService) {}

  ngOnInit(): void {
    // Observe current user authentication state
    this.currentUser$ = this.authService.getCurrentUser();

    // Fetch user-specific favorites count
    this.favoritesCount$ = this.bookService.getFavorites().pipe(
      map(favorites => favorites.length)
    );
  }

  logout(): void {
    this.authService.logout();
  }
}
