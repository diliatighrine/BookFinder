import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {AngularFireAuth} from '@angular/fire/compat/auth';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private afAuth: AngularFireAuth, private db: AngularFirestore) {}

  // Register a new user
  register(email: string, password: string): Promise<any> {
    return this.afAuth.createUserWithEmailAndPassword(email, password);
  }

  // Login an existing user
  login(email: string, password: string): Promise<any> {
    return this.afAuth.signInWithEmailAndPassword(email, password);
  }

  // Logout the current user
  logout(): Promise<void> {
    return this.afAuth.signOut();
  }

  // Get current user data
  getCurrentUser(): Observable<any> {
    return this.afAuth.authState.pipe(
      map(user => user)
    );
  }

  // Get user's favorite books from Firestore
  getFavorites(userId: string): Observable<any[]> {
    return this.db.collection('favorites', ref => ref.where('userId', '==', userId)).valueChanges();
  }

  // Add a book to the user's favorites
  addToFavorites(userId: string, book: any): Promise<void> {
    const bookId = book.id;
    return this.db.collection('favorites').doc(`${userId}_${bookId}`).set({
      userId,
      bookId,
      book
    });
  }

  // Remove a book from the user's favorites
  removeFromFavorites(userId: string, bookId: string): Promise<void> {
    return this.db.collection('favorites').doc(`${userId}_${bookId}`).delete();
  }
}
