import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {BehaviorSubject, Observable, switchMap} from 'rxjs';
import { map } from 'rxjs/operators';
import { Book } from '../../shared/models/book.model';
import {AuthService} from './auth.service';
import {AngularFirestore} from '@angular/fire/compat/firestore';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private googleBooksApiUrl = 'https://www.googleapis.com/books/v1/volumes';
  private apiKey = 'AIzaSyCFtFVHqxUhW_xQNvNt9AqsxMNrv3g7Q5w'; // Replace with your API key


  constructor(private http: HttpClient, private authService: AuthService, private db: AngularFirestore) {}

  // Search books using Google Books API
  searchBooks(query: string, startIndex: number = 0, maxResults: number = 15): Observable<any[]> {
    const url = `${this.googleBooksApiUrl}?q=${query}&startIndex=${startIndex}&maxResults=${maxResults}&key=${this.apiKey}`;
    return this.http.get<any>(url).pipe(
      map((response) => response.items || [])
    );
  }

  // Get book details by ID
  getBookById(bookId: string): Observable<any> {
    const url = `${this.googleBooksApiUrl}/${bookId}?key=${this.apiKey}`;
    return this.http.get<any>(url).pipe(
      map((response) => response.volumeInfo) // Extract book details
    );
  }

  // Add book to favorites
  addToFavorites(book: any): void {
    this.authService.getCurrentUser().subscribe(user => {
      if (user) {
        this.db.collection('favorites').doc(`${user.uid}_${book.id}`).set({
          userId: user.uid,
          bookId: book.id,
          book
        });
      }
    });
  }

  // Remove book from favorites
  removeFromFavorites(bookId: string): void {
    this.authService.getCurrentUser().subscribe(user => {
      if (user) {
        this.db.collection('favorites').doc(`${user.uid}_${bookId}`).delete();
      }
    });
  }

  getFavorites(): Observable<any[]>  {
    return this.authService.getCurrentUser().pipe(
      switchMap(user => {
        if (!user) return [];
        return this.db.collection('favorites', ref => ref.where('userId', '==', user.uid)).valueChanges();
      })
    );
  }


  getBooksByCategory(category: string, startIndex: number = 0, maxResults: number = 15): Observable<any[]> {
    const url = `${this.googleBooksApiUrl}?q=subject:${category}&startIndex=${startIndex}&maxResults=${maxResults}&key=${this.apiKey}`;
    return this.http.get<any>(url).pipe(
      map((response) => response.items || [])
    );
  }

  getBooksByCategoryAndSearchQuery(query: string ,category: string, startIndex: number = 0, maxResults: number = 15): Observable<any[]> {
    const url = `${this.googleBooksApiUrl}?q=${query}+subject:${category}&startIndex=${startIndex}&maxResults=${maxResults}&key=${this.apiKey}`;
    return this.http.get<any>(url).pipe(
      map((response) => response.items || [])
    );
  }


}
